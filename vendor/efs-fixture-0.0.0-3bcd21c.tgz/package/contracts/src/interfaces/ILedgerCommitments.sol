// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

import {Action, FamilyId, Intent, Native, PostingKey, ReadSet, TypeId} from "./Actions.sol";

/// @title ILedgerCommitments — the commitment encoders (design §5.8)
/// @notice On the ingress address; pure/view encoders the SDK proves equivalent in CI from `vectors/`, never on
///         the hot path.
interface ILedgerCommitments {
    function actionsHash(Action[] calldata actions) external pure returns (bytes32);

    /// The signed lanes' retry key, chain-free:
    /// keccak(abi.encode(DOM_SIGNED_INTENT, hashStruct(intent), actionsHash)).
    function intentDigest(Intent calldata intent, bytes32 actionsHash)
        external
        pure
        returns (bytes32);

    /// The EIP-712 digest the key or wallet signs:
    /// keccak(0x1901 ‖ domainSeparator ‖ hashStruct(IntentWithActions{intent, actionsHash})); never stored.
    function signingDigest(bytes32 domainSeparator, Intent calldata intent, bytes32 actionsHash)
        external
        pure
        returns (bytes32);

    /// keccak(abi.encode(DOM_NATIVE_INTENT, realmId, principalId, ctx.nonce, ctx.deadline,
    /// ctx.expectedExecutionSet, ctx.expectedAcceptanceProfile, guardHash, actionsHash));
    /// guardHash = keccak(raw guard bytes).
    function nativeIntentDigest(
        bytes32 realmId,
        bytes32 principalId,
        Native calldata ctx,
        bytes32 actionsHash,
        bytes32 guardHash
    ) external pure returns (bytes32);

    function publicationIdOf(bytes32 principalId, bytes32 intentDigest)
        external
        pure
        returns (bytes32);

    /// keccak(abi.encode(rs)); equal to guardHash for every accepted guarded publication, because the ingress
    /// requires the raw guard bytes to be the canonical encoding.
    function readSetHash(ReadSet calldata rs) external pure returns (bytes32);

    /// Head-snapshot profile 2, what a read set's `expectedHeads` entry must equal:
    /// `keccak256(abi.encode(state, revision, admission, target))`, where `target` is the head's STORED target
    /// word: the current target of a BOUND head, the LAST BOUND target of a MASKED or RELEASED head, and 0 for a
    /// head that was never bound (UNSET, or a hide with no bind before it; its `targetKind` is 0). It is not the
    /// canonical target the head reads serve, which is 0 for every head that is not BOUND.
    /// A caller computes it from the values its plan was decided on. A hash copied from a read proves nothing
    /// about what the caller saw.
    function headSnapshotHash(uint8 state, uint64 revision, uint64 admission, bytes32 target)
        external
        pure
        returns (bytes32);

    function acceptanceProfileOf(address ledger, Action[] calldata actions)
        external
        view
        returns (bytes32);

    function indexObligationsOf(address ledger) external view returns (bytes32);

    /// Estimation: the kernel's index-floor quote (design §10.4) without a principal. Every BIND and UNBIND then reads
    /// an UNSET head and is priced as a first statement, so the prefix floor is an upper bound only (exact when every
    /// bind-kind action is a first statement, or there is none); the final reserve does not depend on heads. A consumer
    /// plans from the gas model's rule (`gas/model.json` `planning`), never from this.
    function indexFloor(address ledger, Action[] calldata actions)
        external
        view
        returns (uint32 prefixFloor, uint32 finalReserve, uint32 freshSlots, uint32 rewrites);
}
