// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

// @title Errors — the EFS error catalog (design §5.6)
// @notice Every revert is a custom error with arguments; the release bundle ships `errors.json`
//         with selector, meaning and retry class. The design names the arguments of every write-path
//         error; where it lists an activation, registry, index or controller error by name only, the
//         argument list was chosen here and is recorded in `docs/ONE-WAY-DOORS.md` before the first
//         release. Acceptor revert data is always discarded; index revert data is always nested inside
//         `E_INDEX_CALL`; nothing has the shape "spent more than allowed" (invariant I11).

// ---- kernel entry and preparation (retry class in the trailing comment) -------------------------------
error AlreadyAdmitted(uint64 publication); // none (committed)
error E_NONCE(bytes32 principalId, uint64 nonce, uint64 publication); // reprepare
error E_PUBLICATION_ACTIVE(); // wait
error E_TRANSITION(uint32 target, uint48 deadline); // wait
error E_CHAIN(uint64 accepted, uint64 actual); // none
error E_NO_INDEX(); // wait
error E_EXECUTION_DRIFT(address live, address activated); // wait
error E_REGISTRY_DRIFT(uint64 expected, uint64 have); // resubmit
error E_HELPER_CODE(address helper); // wait
error E_EXECUTION_SET(bytes32 expected, bytes32 live); // reprepare
error E_ACCEPTANCE_PROFILE(bytes32 expected, bytes32 live); // reprepare
error E_NATIVE_AMBIGUOUS(); // none
error E_BATCH_SHAPE(uint16 actions, uint16 bodies); // none
error E_COUNTER_SATURATED(uint8 counter); // none
error E_EXPIRED(uint64 deadline, uint64 now); // reprepare
error E_INTENT(uint8 field); // reprepare: 1 realm 2 execution 3 profile 4 index 5 readset
error E_SIGNATURE(uint8 reason); // reprepare: 0 unknown profile 1 length 2 malleable 3 recover 4 wallet refused 5 code-less/key-classified author 6 author does not derive principalId
error E_WALLET_GAS(uint32 forwarded); // resubmit
error E_READSET_SHAPE(uint8 reason); // none: 1 principals 2 positions 3 heads length 4 not the canonical encoding 5 principals x positions over maxReadCount
error E_READSET_STALE(bytes32 position, bytes32 principalId); // reprepare
error E_UNSUPPORTED_GUARD(); // none
error E_VERIFIER_PROFILE(uint16 profile); // none
error E_UNKNOWN_TYPE(uint8 leaf, bytes32 typeId); // none

// ---- per-leaf apply and validation ----------------------------------------------------------------------
error E_SHAPE(uint8 leaf, uint8 code); // none
error E_KIND(uint8 leaf, uint8 kind); // none
error E_BODY(uint8 leaf, uint8 code); // none: 1 too long 2 hash mismatch 3 carrier refused
error E_MISSING_RECORD(uint8 leaf, bytes32 recordId); // reprepare
error E_TYPE_MISMATCH(uint8 leaf, bytes32 expected, bytes32 have); // none
error E_REF(uint8 leaf, uint8 refIndex, uint8 code); // reprepare: 1 missing 2 type 3 sentinel-in-body 4 reserved sentinel
error E_ACCEPTOR_CODE(uint8 leaf, address acceptor); // wait
error E_GAS(uint8 leaf, uint32 needed, uint32 available); // resubmit
error E_ACCEPTOR_GAS(uint8 leaf, bytes32 typeId, uint32 forwarded); // resubmit
error E_REJECTED(uint8 leaf, bytes32 typeId); // none
error E_POLICY_REJECTED(uint8 leaf, bytes32 typeId, uint16 policyRow); // none
error E_NOT_LIVE(uint8 leaf, bytes32 bindingKey, uint8 state); // reprepare
error E_CAS(bytes32 bindingKey, uint64 expected, uint64 have); // reprepare
error E_TARGET_MISSING(uint8 leaf, bytes32 target); // reprepare
error E_TARGET_TYPE(uint8 leaf, bytes32 expected, bytes32 have, uint16 roleRow); // none
error E_SUBJECT_EXISTS(uint8 leaf, bytes32 subjectId); // none
error E_SALT(uint8 leaf); // none
error E_WITHDRAW(uint8 leaf, uint8 code); // none: 0 range 1 not publish 2 already 3 not author

// ---- delegates and the index dispatcher ------------------------------------------------------------------
error E_INGRESS(uint256 replySize); // wait
error E_INDEX_CALL(bytes inner); // none (the callback reverted with data; inner ≤ 4,096 B)
error E_INDEX_GAS(uint32 quoted, uint32 available); // resubmit
error E_INDEX_RETURNDATA(uint256 size); // none
error E_WORK_MODEL(uint8 code, uint256 value); // none: the live index's work model (`IIndexReads.workModel()`, read as raw words by the ingress) is not one this build implements: 1 the call failed (value = the reply's size) 2 the reply is not `WORK_MODEL_WORDS` words (value = its size) 3 its word 0, `formulaVersion`, is not `FORMULA_VERSION` (value = that word). A formula-2 index under a formula-3 ingress is 2 (17 words); replace the index
error E_INDEX_FINAL(); // none
error E_INDEX_ACK(uint8 phase); // none: a callback returned without the exact 32-byte selector acknowledgement (phase 2 prefix, 3 final)
error E_DELEGATE_ONLY(); // none

// ---- activation, transition, freeze and the controller (design §8) ---------------------------------------
error E_REVISION(uint32 expected, uint32 have); // reprepare: a set or a transition must name revision current + 1
error E_IMPLEMENTATION(address expected, address live); // none
error E_LAYOUT(bytes32 expected, bytes32 have); // none
error E_REGISTRY(uint8 field); // none: 1 activeRevision 2 ledger 3 implementation 4 codehash
error E_PIN(address target, uint8 which); // none: 1 ingress 2 apply 3 index 4 controller codehash 5 unit 6 store 7 build 8 the ERC-1967 admin slot is not the proxy's first creation 9 the controller does not own that ProxyAdmin 10 the index's reads contract (its codehash is not the one the index recorded, or its manifest names another header, profile or ledger) 11 the index's topic Type ids (one of them zero, or nonzero without a final unit whose topicTypeId() and topicWordTypeId() equal them) 12 the reads contract's copy of the live index's manifest (`IIndexReads.liveManifestCopy`) cannot be held: it exceeds 24,575 B, the code size limit (EIP-170) of the data contract that holds it less its leading STOP byte, or that contract could not be created 13 the index's work model cannot be held as the code of a data contract (the contract could not be created, or its code is not one STOP byte and the encoded work model)
error E_INDEX_NOT_READY(uint8 reason); // none: activation of the index (design §8.3 5g–5h). An unchanged index (its readiness is never asked: it is pinned by the revision row; only its work model is read, reasons 15 and 16): 1 codehash or manifest hash other than the revision row's 2 the ledger's own publication lock is not IDLE (LedgerCore's activate and freeze are idle-gated, so this is the control body's own guard). A new index: 3 its readiness names another ledger 4 another layout 5 an unsupported hot ABI 6 another manifest hash 7 a phase other than IDLE 8 completedAdmission or completedPublication is not the ledger's counts (behind: build or replay again) 9 an APPEND family maintained from an admission other than 1 10 a family's store does not list it 11 a store's writer ranges are not contiguous 12 a carried family is not the live index's (with admissions: a family in a store that does not name the candidate as INITIAL_WRITER is not declared in the same store from admission 1 by the live index's manifest, read from the candidate's verified copy of it, reason 14), or on an empty Realm a store has already been written (its writers list is not empty) or names an INITIAL_WRITER other than 0 and the candidate (that contract could write it in build mode until a live write attaches it) 13 a store that names the candidate as INITIAL_WRITER is already attached (with admissions) 14 the candidate carries a store and its copy of the live index's manifest (`IIndexReads.liveManifestCopy`) is not the manifest the kernel recorded for the current revision (its keccak differs from the row's indexManifestHash: empty, altered, another index's, or stale because the live index was replaced after the candidate was deployed; redeploy it with a fresh copy) 15 the index's work model (`IIndexReads.workModel()`) is not one this activation's ingress implements: its reply is not `WORK_MODEL_WORDS` words or its `formulaVersion` is not the ingress's `formulaVersion()` (checked for a kept index too, so a new ingress never runs under an index of another formula) 16 a word of that work model does not fit its field (`uint16`, or `uint32` for the compute terms; the ingress reads the words whole, without the ABI decoder's range checks)
error E_EXPECTED_SET(bytes32 expected, bytes32 live); // reprepare: the set names an execution set other than the one the live components hash to
error E_FROZEN(); // none: the Realm is frozen
error E_NOT_CONTROLLER(address caller); // none
error E_DEADLINE_BOUND(uint48 deadline, uint32 maxBlocks); // reprepare: the transition deadline is before the current block or more than maxBlocks past it
error E_TRANSITION_COOLDOWN(uint48 until); // wait: no new transition before block `until`
error E_TRANSITION_TARGET(uint32 target); // none
error E_MIGRATION_SCOPE(bytes32 root); // none
error E_HOT_ABI(address unit); // none
error E_CODE_SHAPE(address target, uint8 reason); // none: 1 no code 2 designator 3 forbidden opcode 4 trailer malformed 5 EIP-1167 proxy 6 codehash mismatch
error E_CONTROLLER(uint8 field); // none: 1 controller 2 codehash 3 owner
error E_FREEZE_PRECHECK(uint8 check); // none
error E_RESERVED(uint8 field, uint256 value); // none: field 32: limits.maxActions outside 1..64 (the replay ceiling); 33: a capability this build does not implement
error E_UNSUPPORTED_ROW(uint8 row); // none

// ---- registry (design §9) ----------------------------------------------------------------------------------
error E_TYPE_EXISTS(bytes32 typeId); // none
error E_BINDING(uint8 code); // none: 1 a binding argument on a grade that takes none 3 custom codehash 4 native codehash 5 binding signed by another key 6 existing row under another predicate 7 signature length 8 malleable 9 unrecoverable 10 binding id recomputed by the wrapper differs from the context's
error E_DECLARATION(uint8 code); // none: 1 signature length 2 malleable or bad v 3 unrecoverable 4 signed by another key
error E_CODEC(uint16 byteOffset, uint8 code); // none: codes 1..26 documented on DescribedCodec.parse; the DescriptorStore uses (0, 1) for an oversized blob
error E_DESIGNATOR(address target); // none
error E_BLOB(address blob); // none
error E_GRADE(uint8 grade); // none
error E_INSTANCE(address expected, address have); // none
error E_WRAPPER(uint8 code); // none: 1 no wrapper row for the header's version 2 wrapper codehash differs from the header's 3 version 0 4 version already activated 5 not a wrapper (constants unreadable)
error E_ROLE_ROWS(); // none

// ---- index and stores (design §10, §4.6) ----------------------------------------------------------------
error E_LEDGER(); // none
error E_WRITER(address caller); // none
error E_ORDER(uint64 expected, uint64 have); // none
error E_STAGED(uint64 expected, uint64 have); // none
error E_FAMILY(bytes32 familyId); // none
error E_UNIT(uint8 index); // none
error E_REPLAY(uint8 code); // none: 1 stores not fresh or already live 2 foreign layout at that publication 3 not idle 5 no decoder 6 maxFacts 7 no such publication 8 unreadable row 9 bind row without an ordinal 10 a PUBLISH/REUSE record's Type: the bytes the registry returned for it (`descriptorBytes`) do not hash to its Type id (altered, truncated, another Type's or empty), so its reference count is unproved; a registry that reverts there makes the decode revert with its own error
error E_BUILD(uint8 code); // none: 1 the generation is live or was activated 2 a store names the generation as INITIAL_WRITER but a live write has attached it (neither fresh nor carried) 3 the ledger is not idle, or a replay or build call of this generation is in flight 5 the generation has a fresh store and no decoder 6 the next publication's leaf count exceeds maxFacts (nothing was folded in this call) 7 the carried check fails (docs INDEX-BUILD §3.5): the generation's copy of the live index's manifest is not the one the kernel recorded (stale, altered or empty), a family the generation carries is not the live index's, or on an empty Realm one of its stores has already been written or names an INITIAL_WRITER other than 0 and the generation 8 a nonzero familyId (one walk builds every built family)
error E_BACKFILL(uint8 code); // none: 0 this generation declares no later family; 1 coverage not open 2 through outside [through, liveFrom]
error E_COVERAGE(uint8 code); // none: 1 already open 2 nothing to retire

// ---- controller (design §5.12) ----------------------------------------------------------------------------
error E_NOT_OWNER(address caller); // none
error E_PENDING(address pending); // none
error E_NOT_IDLE(); // wait: a controller ceremony is in progress
error E_SUCCESSOR(uint8 code); // none: 1 codehash 2 controller field 3 owner 4 admins not moved 5 self 6 retired or frozen 7 another ledger 8 another registry
error E_RETIRED(); // none
error E_CANARY(uint8 lane); // none
error E_GENESIS(uint8 step); // none: 0 already run 1 limits hash 2 controller address 3 registry proxy address 4 ledger proxy address 5..8 post-checks 9 implementation codehash 10 initcode hash 11 creation failed
error E_DEPLOYER(uint8 step); // none: 0 already run 1 plan hash 2 store or reads-contract address 3 generation address 4 generation ledger

// ---- reader directory (design §5.13) ----------------------------------------------------------------------
error E_READER(address reader, uint8 code); // none: 1 already listed 2 names another ledger 3 malformed reply 4 list full
