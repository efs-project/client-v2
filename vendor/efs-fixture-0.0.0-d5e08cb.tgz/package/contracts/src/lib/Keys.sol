// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

/// @title Keys — the EFS identity derivations
/// @notice Every permanent id the kernel mints is derived here and nowhere else. The domain tags, the
///         argument order and the ABI encoding are the prototype's (lab-b `src/Keys.sol`, itself copied
///         from the c0-core model) and are one-way doors: changing any of them changes every id ever
///         minted. Nothing here depends on a proxy address, an implementation codehash, a chain id or
///         compiler metadata, except the genesis `realmOrigin` that qualifies contract principals.
/// @dev Consumer-closure library: pure/view, no storage, no external calls beyond `extcodecopy`,
///      no OpenZeppelin, nothing from EIP-1153. Golden vectors for every function live in
///      `test/vectors/ids.json` and are produced by an independent implementation (`tools/vectors.mjs`).
library Keys {
    // Record id: keccak256(abi.encode(DOM_RECORD, typeId, keccak256(body)))
    bytes32 internal constant DOM_RECORD = keccak256("efs/record/1");
    // Position: keccak256(abi.encode(DOM_POSITION, purpose, subject, role))
    bytes32 internal constant DOM_POSITION = keccak256("efs/position/1");
    // Binding key: keccak256(abi.encode(DOM_BINDING, principal, position))
    bytes32 internal constant DOM_BINDING = keccak256("efs/binding/1");
    // Scope key: keccak256(abi.encode(DOM_SCOPE, principal, purpose, subject))
    bytes32 internal constant DOM_SCOPE = keccak256("efs/vk/binding-scope/1");
    // Posting key: keccak256(abi.encode(DOM_POSTING, typeId, uint256(kind), uint256(ordinal), valueKey))
    bytes32 internal constant DOM_POSTING = keccak256("efs/pk/1");
    // Subject id: keccak256(abi.encode(DOM_SUBJECT, creatorPrincipal, creatorSalt)) — depends only on the
    // creating principal and its salt, never on chain state, so the same create yields the same subject
    // id on every deployment.
    bytes32 internal constant DOM_SUBJECT = keccak256("efs/subject/1");
    // Contract principal: keccak256(abi.encode(DOM_PRINCIPAL, uint256(2), realmOrigin, address)). A contract
    // address is not unique across Realms; a key is, so key principals stay the left-padded address.
    bytes32 internal constant DOM_PRINCIPAL = keccak256("efs/principal/1");
    // Exact Type id: keccak256(abi.encode(DOM_TYPE, shape, keccak256(abi.encode(refTypes)), ruleId)).
    // The id commits to the Type's descriptor shape, its checked-reference Types in order and its
    // declared rule identity, so the same descriptor yields the same id on every Realm and a changed
    // descriptor is a different Type, never a re-registration.
    bytes32 internal constant DOM_TYPE = keccak256("efs/type/1");
    // Role-scope key: keccak256(abi.encode(DOM_ROLE_SCOPE, principal, purpose, role)) — the index family 16 key
    bytes32 internal constant DOM_ROLE_SCOPE = keccak256("efs/vk/role-scope/1");
    // Scope-below key: keccak256(abi.encode(DOM_SCOPE_BELOW, principal, purpose, ancestor)) — the index family 19 key:
    // one list per (author, purpose, proper ancestor of the topic a first statement is made on)
    bytes32 internal constant DOM_SCOPE_BELOW = keccak256("efs/vk/scope-below/1");
    // Realm origin: keccak256(abi.encode(DOM_REALM_ORIGIN, genesisChainId, coreAddress, realmSalt)) — the one
    // identity input that names a chain and an address; it qualifies contract principals (design §1.2 row 12)
    bytes32 internal constant DOM_REALM_ORIGIN = keccak256("efs/realm-origin/1");
    // Realm id: keccak256(abi.encode(DOM_REALM, realmOrigin, genesisExecutionProfileId))
    bytes32 internal constant DOM_REALM = keccak256("efs/realm/1");
    // Publication id: keccak256(abi.encode(DOM_PUBLICATION, principalId, intentDigest)) — emitted, never stored
    bytes32 internal constant DOM_PUBLICATION = keccak256("efs/publication/1");
    // Native intent digest (design §5.8): keccak256(abi.encode(DOM_NATIVE_INTENT, realmId, principalId, nonce,
    // deadline, expectedExecutionSet, expectedAcceptanceProfile, guardHash, actionsHash)) — the retry key
    bytes32 internal constant DOM_NATIVE_INTENT = keccak256("efs/native-intent/1");
    // Signed intent digest (chain-free retry key): keccak256(abi.encode(DOM_SIGNED_INTENT, hashStruct(intent), actionsHash))
    bytes32 internal constant DOM_SIGNED_INTENT = keccak256("efs/signed-intent/1");
    // Acceptance profile fold seed: keccak256(abi.encode(DOM_PROFILE, executionSet)), folded per leaf (design §6.2)
    bytes32 internal constant DOM_PROFILE = keccak256("efs/acceptance-profile/1");
    // Descriptor shape: keccak256(abi.encode(DOM_DESCRIBED_SHAPE, descriptorBytes))
    bytes32 internal constant DOM_DESCRIBED_SHAPE = keccak256("efs/described-shape/1");
    // Registry role key: keccak256(abi.encode(DOM_ROLE_KEY, purpose, role))
    bytes32 internal constant DOM_ROLE_KEY = keccak256("efs/role-key/1");
    // Execution set (design §8.1): keccak256(abi.encode(DOM_EXECUTION_SET, layoutId, domainSeparator, ComponentSet,
    // revisionOrdinal, executionProfileId, capabilities, acceptedChainId, limitsProfileId))
    bytes32 internal constant DOM_EXECUTION_SET = keccak256("efs/execution-set/1");

    // Posting-list kinds. 2, 3, 9 are reserved (never minted).
    uint8 internal constant KIND_BY_TYPE = 1;
    uint8 internal constant KIND_BY_AUTHOR = 4;
    uint8 internal constant KIND_BACKLINK = 5;
    uint8 internal constant KIND_HISTORY = 8;
    uint8 internal constant KIND_SCOPE = 10;
    uint8 internal constant KIND_REFERENCE_POSITION = 11;
    uint8 internal constant KIND_BY_RECORD = 12;
    uint8 internal constant KIND_UNIQUE_BY_TYPE = 13;
    uint8 internal constant KIND_SCALAR = 14;
    uint8 internal constant KIND_DIGEST = 15;
    uint8 internal constant KIND_PLACE = 6;
    uint8 internal constant KIND_PLACE_BELOW = 7;
    uint8 internal constant KIND_SCOPE_BELOW = 19;
    uint8 internal constant KIND_POSITION_AUTHORS = 20;
    uint8 internal constant KIND_ROLE_PLACES = 21;

    /// Key principal id: the left-padded address. The same key names the same principal on every Realm.
    function principal(address account) internal pure returns (bytes32) {
        return bytes32(uint256(uint160(account)));
    }

    /// Contract principal id, qualified by the Realm that observed it (kind 2).
    function contractPrincipal(bytes32 origin, address account) internal pure returns (bytes32) {
        return keccak256(abi.encode(DOM_PRINCIPAL, uint256(2), origin, account));
    }

    /// The principal an account authors as. EIP-7702 delegation changes execution, not the signing
    /// key's namespace: exactly the 23-byte `ef0100 ‖ address` designator is a key principal, without
    /// following its target. Any other code is a contract principal of this Realm.
    function principalFor(address account, bytes32 origin) internal view returns (bytes32) {
        uint256 size = account.code.length;
        if (size == 0) return principal(account);
        if (size == 23) {
            bytes3 prefix;
            assembly ("memory-safe") {
                extcodecopy(account, 0, 0, 3)
                prefix := mload(0)
            }
            if (prefix == hex"ef0100") return principal(account);
        }
        return contractPrincipal(origin, account);
    }

    /// Role-scope key (index family 16): one list per (principal, purpose, role).
    function roleScope(bytes32 principalId, bytes32 purpose, bytes32 role)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(DOM_ROLE_SCOPE, principalId, purpose, role));
    }

    /// Scope-below value key (index family 19): one list per (author, purpose, ancestor topic).
    function scopeBelow(bytes32 principalId, bytes32 purpose, bytes32 ancestor)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(DOM_SCOPE_BELOW, principalId, purpose, ancestor));
    }

    /// Realm origin: fixed at genesis; the only id that names a chain and an address.
    function realmOrigin(uint64 genesisChainId, address core, bytes32 realmSalt)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(DOM_REALM_ORIGIN, genesisChainId, core, realmSalt));
    }

    /// Realm id over the origin and the genesis execution profile.
    function realmId(bytes32 origin, uint16 genesisExecutionProfileId)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(DOM_REALM, origin, genesisExecutionProfileId));
    }

    /// Publication id on every lane (design §7.3).
    function publicationId(bytes32 principalId, bytes32 intentDigest)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(DOM_PUBLICATION, principalId, intentDigest));
    }

    /// Registry role key for role-expectation rows.
    function roleKey(bytes32 purpose, bytes32 role) internal pure returns (bytes32) {
        return keccak256(abi.encode(DOM_ROLE_KEY, purpose, role));
    }

    /// Descriptor shape commitment (design §9.1).
    function shape(bytes calldata descriptor) internal pure returns (bytes32) {
        return keccak256(abi.encode(DOM_DESCRIBED_SHAPE, descriptor));
    }

    /// Index family id: keccak256("efs/family/<name>/1") (design §10.2).
    function familyId(string memory name) internal pure returns (bytes32) {
        return keccak256(abi.encodePacked("efs/family/", name, "/1"));
    }

    /// Exact Type id from its descriptor commitment, checked-reference Types and rule identity.
    function typeId(bytes32 shape_, bytes32[] memory refTypes, bytes32 ruleId)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(DOM_TYPE, shape_, keccak256(abi.encode(refTypes)), ruleId));
    }

    function record(bytes32 typeId_, bytes memory body) internal pure returns (bytes32) {
        return keccak256(abi.encode(DOM_RECORD, typeId_, keccak256(body)));
    }

    /// Same id as `record`, from an already-computed body hash (a signed Action carries the hash).
    function recordFromHash(bytes32 typeId_, bytes32 bodyHash) internal pure returns (bytes32) {
        return keccak256(abi.encode(DOM_RECORD, typeId_, bodyHash));
    }

    function subject(bytes32 creator, bytes32 creatorSalt) internal pure returns (bytes32) {
        return keccak256(abi.encode(DOM_SUBJECT, creator, creatorSalt));
    }

    function position(bytes32 purpose, bytes32 subjectKey, bytes32 role)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(DOM_POSITION, purpose, subjectKey, role));
    }

    function binding(bytes32 principalId, bytes32 positionKey) internal pure returns (bytes32) {
        return keccak256(abi.encode(DOM_BINDING, principalId, positionKey));
    }

    function scope(bytes32 principalId, bytes32 purpose, bytes32 subjectKey)
        internal
        pure
        returns (bytes32)
    {
        return keccak256(abi.encode(DOM_SCOPE, principalId, purpose, subjectKey));
    }

    function posting(bytes32 typeId_, uint8 kind, uint8 ordinal, bytes32 valueKey)
        internal
        pure
        returns (bytes32)
    {
        return
            keccak256(abi.encode(DOM_POSTING, typeId_, uint256(kind), uint256(ordinal), valueKey));
    }

    function byTypeList(bytes32 typeId_) internal pure returns (bytes32) {
        return posting(typeId_, KIND_BY_TYPE, 0, bytes32(0));
    }

    function byAuthorList(bytes32 principalId) internal pure returns (bytes32) {
        return posting(bytes32(0), KIND_BY_AUTHOR, 0, principalId);
    }

    /// Family 5 is keyed by (purpose, target), the purpose in the key's first word: a file's folder placements and
    /// its tags are two lists with two live counts (design §10.2).
    function backlinkList(bytes32 purpose, bytes32 target) internal pure returns (bytes32) {
        return posting(purpose, KIND_BACKLINK, 0, target);
    }

    function historyList(bytes32 bindingKey) internal pure returns (bytes32) {
        return posting(bytes32(0), KIND_HISTORY, 0, bindingKey);
    }

    function scopeList(bytes32 scopeKey) internal pure returns (bytes32) {
        return posting(bytes32(0), KIND_SCOPE, 0, scopeKey);
    }

    function referenceList(bytes32 sourceType, uint8 ordinal, bytes32 target)
        internal
        pure
        returns (bytes32)
    {
        return posting(sourceType, KIND_REFERENCE_POSITION, ordinal, target);
    }

    function byRecordList(bytes32 recordId) internal pure returns (bytes32) {
        return posting(bytes32(0), KIND_BY_RECORD, 0, recordId);
    }

    function uniqueByTypeList(bytes32 typeId_) internal pure returns (bytes32) {
        return posting(typeId_, KIND_UNIQUE_BY_TYPE, 0, bytes32(0));
    }

    function scalarList(bytes32 typeId_, uint8 spec, uint8 kind, bytes32 value)
        internal
        pure
        returns (bytes32)
    {
        return posting(typeId_, KIND_SCALAR, spec, keccak256(abi.encode(kind, value)));
    }

    function digestList(bytes32 algorithm, bytes32 value) internal pure returns (bytes32) {
        return posting(bytes32(0), KIND_DIGEST, 0, keccak256(abi.encode(algorithm, value)));
    }

    /// Family 6 (`place`), keyed by (purpose, subject), the purpose in the key's first word as in family 5: one
    /// entry per filing, by anyone — the first statement at a fresh position (either sign) and every later author's
    /// first yes — in order of filing, so a position may appear more than once (design §10.2). `count` = filings;
    /// `live` = distinct positions ever stated at the place, an "about" count that includes positions nobody says
    /// yes to now (not the number of rows an Everyone view returns).
    function placeList(bytes32 purpose, bytes32 subjectKey) internal pure returns (bytes32) {
        return posting(purpose, KIND_PLACE, 0, subjectKey);
    }

    /// Family 7 (`place-below`), keyed by (purpose, ancestor): one entry per filing (as family 6) at any topic below
    /// `ancestor`, by anyone (generation 1 writes it for TAG only); `count` = filings, `live` = distinct positions
    /// ever stated below it (the same "about" count as family 6).
    function placeBelowList(bytes32 purpose, bytes32 ancestor) internal pure returns (bytes32) {
        return posting(purpose, KIND_PLACE_BELOW, 0, ancestor);
    }

    /// Family 19 (`scope-below`), keyed by (author, purpose, ancestor): one entry per first statement of the author
    /// on any topic below `ancestor` (generation 1 writes it for TAG only).
    function scopeBelowList(bytes32 principalId, bytes32 purpose, bytes32 ancestor)
        internal
        pure
        returns (bytes32)
    {
        return posting(bytes32(0), KIND_SCOPE_BELOW, 0, scopeBelow(principalId, purpose, ancestor));
    }

    /// Family 20 (`position-authors`), keyed by the position id: one entry per author's first statement there
    /// (either sign). `count` = the authors who ever stated there; `live` = the authors whose head there is BOUND now
    /// (a counter the index moves on a first yes, a mask or release of a BOUND head and a restore; design §10.2).
    function positionAuthorsList(bytes32 positionKey) internal pure returns (bytes32) {
        return posting(bytes32(0), KIND_POSITION_AUTHORS, 0, positionKey);
    }

    /// Family 21 (`role-places`), keyed by (purpose, role), the purpose in the key's first word: one entry per
    /// distinct position with that role, whatever its subject (for a tag the role is the thing tagged).
    function rolePlacesList(bytes32 purpose, bytes32 role) internal pure returns (bytes32) {
        return posting(purpose, KIND_ROLE_PLACES, 0, role);
    }
}
