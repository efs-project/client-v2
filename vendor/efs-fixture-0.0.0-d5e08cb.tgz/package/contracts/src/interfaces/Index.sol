// SPDX-License-Identifier: MIT
pragma solidity ^0.8.27;

// Index — the structs of the required-index ABI (design §5.11, §10), shared by `IRealmIndex`, `IIndexHook`,
// `IIndexReads` and the kernel-internal delegates.

/// Effect/3: 24 static words (768 B); callbackProfile =
/// keccak("efs/index-callback/4:ordered-prefix:static-final:effect-24:refs") (callback 4 is the Effect/3 shape with
/// transition kind 6 and target kind 3 added). transitionKind: 0 none (publish/reuse/create/withdraw) 1 FIRST_BIND
/// 2 REBIND 3 MASK (UNBIND from BOUND, MASKED or RELEASED) 4 RELEASE 5 RESTORE (BIND from MASKED/RELEASED)
/// 6 FIRST_MASK (UNBIND from UNSET: the binding is allocated with no target). targetKind/oldTargetKind: 0 none
/// 1 RECORD 2 SUBJECT 3 ADDRESS. freshRecord: first admission of recordId. refCount: how many entries of `refs` belong
/// to this effect, in order. WITHDRAW: recordId/typeId of the withdrawn record, withdrawnAdmission = target
/// admission, withdrawnPrincipal = its retained principal.
struct Effect {
    uint8 kind;
    uint8 leaf;
    uint64 admission;
    uint64 publication;
    bytes32 principalId;
    bytes32 typeId;
    bytes32 recordId;
    bytes32 subjectId;
    uint64 bindingOrdinal;
    bytes32 position;
    bytes32 purpose;
    bytes32 subject;
    bytes32 role;
    uint64 revision;
    uint64 prevAdmission;
    uint8 transitionKind;
    uint8 targetKind;
    uint8 oldTargetKind;
    uint8 refCount;
    bool freshRecord;
    bytes32 target;
    bytes32 oldTarget;
    uint64 withdrawnAdmission;
    bytes32 withdrawnPrincipal;
}

/// Slot counts (×10) and compute; converted with limits.floor* at quote time (design §10.4). Formula 2, over a
/// publication of n actions, `binds` of them BIND/UNBIND/RELEASE and `publishes` PUBLISH/REUSE:
///   fresh10 = freshPerPublication + Σ_publishes (freshPerRef·refs + (new record ? freshPerPublishFresh +
///             freshPerDigestSpec·specs : freshPerPublishExisting)) + Σ_binds (first statement ? freshPerBindFresh : 0)
///   rw10    = rwPerPublication + publishes·rwPerPublish + Σ_binds (rwPerBind + (first statement ? 0 : rwPerBindLater))
///   prefixFloor  = computeBase + n·computePerAction + binds·computePerHookEffect + ceil(fresh10/10)·floorFreshGas
///                  + ceil(rw10/10)·floorRewriteGas
///   finalReserve = finalComputeBase + binds·finalComputePerBind + publishes·finalComputePerPublish
/// A first statement is a BIND or UNBIND on an UNSET author head (it allocates the binding); every other bind-kind
/// action, a RELEASE always, is a later statement. A record is new when no earlier admission wrote its header (a
/// REUSE always names an existing one).
struct WorkModel {
    uint8 formulaVersion;
    uint16 freshPerPublication;
    uint16 rwPerPublication;
    uint16 freshPerPublishFresh;
    /// Charged instead of `freshPerPublishFresh` for a PUBLISH of an existing record or a REUSE: filing a record
    /// again writes more fresh index slots than its first admission (measured ≈ 2.4 per action against 0.6).
    uint16 freshPerPublishExisting;
    uint16 rwPerPublish;
    uint16 freshPerBindFresh;
    uint16 rwPerBind;
    /// Charged on a later statement (a re-bind, a number change, a mask, a release, a restore) on top of `rwPerBind`:
    /// it moves the lists and counts a first statement only appends to, so the per-bind terms, set from first
    /// statements, under-quote it.
    uint16 rwPerBindLater;
    uint16 freshPerRef;
    uint16 freshPerDigestSpec;
    uint32 computeBase;
    uint32 computePerAction;
    uint32 computePerHookEffect;
    uint32 finalComputeBase;
    uint32 finalComputePerBind;
    /// The final phase's compute per PUBLISH or REUSE: the final units see every effect, not only the bind-kind ones.
    uint32 finalComputePerPublish;
}

// `WorkModel`'s ABI size in words: a static struct, one word per field, returned inline by `IIndexReads.manifest()`
// between the three array offsets and the two profiles, so a reader that checks the profiles from the raw reply finds
// them at words 4 + WORK_MODEL_WORDS and 5 + WORK_MODEL_WORDS. It must change with the struct;
// `test/index/IndexReadsSplit.t.sol` fails when the two drift.
uint256 constant WORK_MODEL_WORDS = 17;

/// Constructor-fixed; the core folds family 15 from body word `wordIndex` (one cold SLOAD, priced).
struct DigestSpec {
    bytes32 typeId;
    uint8 wordIndex;
    uint8 algorithm;
}

/// One pinned index unit: its fold and final hooks with codehashes, its families, and the
/// hot-ABI id it was built against.
struct Unit {
    address foldHook;
    bytes32 foldCodehash;
    address finalHook;
    bytes32 finalCodehash;
    bytes32[] familyIds;
    bytes32 purposeFilter;
    bytes32 hotAbiId;
    bytes32 identity;
}

/// One index family. kind: the §10.2 kind number (0 reserved); universe: 1 TYPE 2 PRINCIPAL 3 SCOPE 4 TARGET
/// 5 GLOBAL; shape: 1 APPEND_ORDERED 2 BITMAP. liveSemantics, read by shape — APPEND: 1 RETAINED (never releases;
/// `live` = `count`) 2 OCCURRENCE (releases on WITHDRAW) 3 HEADS (tracks the entries' current heads) 4 DISTINCT
/// (`live` is raised only by a counted append and never lowered; `count` is every entry, so `live` ≤ `count`);
/// BITMAP: 1 MONOTONE 2 CURRENT_STATE; 0 reserved. fromAdmission NOT_MAINTAINED = 2^64-1.
struct FamilyEntry {
    bytes32 familyId;
    uint8 kind;
    uint8 universe;
    uint8 shape;
    bool mandatory;
    uint8 liveSemantics;
    bytes32 recipe;
    uint64 fromAdmission;
    address store;
    bytes32 storeCodehash;
}

/// A generation's readiness tuple. phase echoes ILedgerHot(ledger).phase(); ready is the §10.5 predicate, which
/// checkActivation re-derives from the tuple and the stores and never trusts.
struct Readiness {
    uint8 version;
    address ledger;
    bytes32 layoutId;
    bytes32 hotAbiId;
    bytes32 physicalProfile;
    bytes32 callbackProfile;
    bytes32 manifestHash;
    uint64 provenFrom;
    uint64 completedAdmission;
    uint64 completedPublication;
    uint8 phase;
    bool ready;
    Unit[] units;
    FamilyEntry[] families;
    address build;
    bytes32 buildCodehash;
}
